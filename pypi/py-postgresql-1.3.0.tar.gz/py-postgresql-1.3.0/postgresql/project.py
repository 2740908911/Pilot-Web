"""
Project information.
"""

name = 'py-postgresql'
identity = 'http://github.com/python-postgres/fe'

meaculpa = 'Python+Postgres'
abstract = 'Driver and tools library for PostgreSQL'

version_info = (1, 3, 0)
version = '.'.join(map(str, version_info))
