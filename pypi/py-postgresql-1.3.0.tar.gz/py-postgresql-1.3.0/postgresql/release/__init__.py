##
# .release
##
"""
Release management code and project/release meta-data.
"""
